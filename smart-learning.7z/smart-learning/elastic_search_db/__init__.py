from elasticsearch import Elasticsearch

ES_HOST = 'ec2-54-165-65-24.compute-1.amazonaws.com'
# ES_HOST = 'localhost'
ES_PORT = 80
# ES_PORT = 9200

INDEX = "smart-learning"
TYPE = "books"
