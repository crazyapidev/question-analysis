
"""
settings for train Question classifier model
"""
"""
choose Classifier
"""
classifier_algo = "RandomForest" #"Logistic" # 

"""
Modeling for EntityType classifier
classes available 
['ABBR:abb', 'ABBR:exp', 'DESC:def', 'DESC:desc', 'DESC:manner', 'DESC:reason', 'ENTY:animal',
'ENTY:body', 'ENTY:color', 'ENTY:cremat', 'ENTY:currency', 'ENTY:dismed', 'ENTY:event', 'ENTY:food',
'ENTY:instru', 'ENTY:lang', 'ENTY:letter', 'ENTY:other', 'ENTY:plant', 'ENTY:product', 'ENTY:religion',
'ENTY:sport', 'ENTY:substance', 'ENTY:symbol', 'ENTY:techmeth', 'ENTY:termeq', 'ENTY:veh', 'ENTY:word',
'HUM:desc', 'HUM:gr', 'HUM:ind', 'HUM:title', 'LOC:city', 'LOC:country', 'LOC:mount', 'LOC:other',
'LOC:state', 'NUM:code', 'NUM:count', 'NUM:date', 'NUM:dist', 'NUM:money', 'NUM:ord', 'NUM:other',
'NUM:perc', 'NUM:period', 'NUM:speed', 'NUM:temp', 'NUM:volsize', 'NUM:weight']

"""

"""
prediction only entity type ( no of classes reduced)
['ABBR','DESC','ENTY','HUM','NUM','LOC']
"""
target_classes = "EntityType" # "EntityOnly"

"""
path to load gensim word vectors
"""
word_vector_path = r"D:\learning_assistant\question_classification\glove.6B.50d.txt"
"""
paths for training and testing data
"""
training_data_path = r"D:\workspacepy\qa-master\question_analysis\ml\data\train_seasons_and_weather_lesson_1.label"
testing_data_path = r"data\TREC_10.label"

"""
trained model path to store or to load
"""
model_path = r"C:\Users\574967\git\smart-learning\QnA_processor\data\models\question_classifiers\model_random_forest.pkl"
# model_path = "D:\learning_assistant\qa-master\question_analysis\ml\models\question_classifiers\model_v1.pkl"

