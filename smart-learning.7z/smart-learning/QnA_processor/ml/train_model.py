import gensim
import numpy as np
import re 
from QnA_processor.question_analysis.ml.utils import load_data,average_vector,compute_accuracy,export_trained_model
from QnA_processor.question_analysis.ml.settings import training_data_path,word_vector_path,target_classes,classifier_algo,model_path


class TrainQuestionClassifier():
    
    def __init__(self,question_vectors,train_labels):
        self.question_vectors = question_vectors        #, dtype=object)
        self.train_labels = train_labels
    
    def train_with_logistic_regression(self):
        from sklearn import linear_model
        classifier = linear_model.LogisticRegression(multi_class='multinomial',solver='lbfgs')
        classifier.fit(self.question_vectors, self.train_labels)
        return classifier
    
    def train_with_random_forest(self):
        from sklearn import linear_model
        classifier = linear_model.LogisticRegression(multi_class='multinomial',solver='lbfgs')
        classifier.fit(self.question_vectors, self.train_labels)
        return classifier
  
  
    
def train_classifier():
    train_data = load_data(training_data_path)
    print (train_data[0:10])
    word_vector = gensim.models.KeyedVectors.load_word2vec_format(word_vector_path, binary=False)
    question_vectors = [average_vector(word_vector, re.sub("-|,|2th"," ",line[1])) for line in train_data]
    
    if target_classes=="EntityType":
        train_labels = [line[0] for line in train_data]
    else :
        train_labels = [line[0].split(":")[0] for line in train_data]
        
    print (len(question_vectors),len(question_vectors[0]),len(train_labels))
    
    train_ques_clfier = TrainQuestionClassifier(question_vectors,train_labels) 
      
    if classifier_algo == "Logistic":
            classifier = train_ques_clfier.train_with_logistic_regression()
    else:
        classifier = train_ques_clfier.train_with_random_forest()
   
    train_data_prediction = [classifier.predict([np.asarray(average_vector(word_vector,line[1].lower()))]) for line in train_data]
    
    print ("Training accuracy " + str(compute_accuracy(train_data_prediction, train_labels)))
    
    """
    export trained model
    """
    export_trained_model(classifier, model_path)
    
    
if __name__ == "__main__":
    train_classifier()


