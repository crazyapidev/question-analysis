
import re
# from annotators import settings

class PreProcess():
    
    def remove_stopwords(self):
        nlp_library = 'spacy'# settings.NLP_ENGINE.lower()
        
        if nlp_library == 'spacy':
            from spacy.lang.en.stop_words import STOP_WORDS as stop_words
        elif nlp_library == 'nltk':
            from nltk.corpus import stopwords as stop_words
    
    def remove_punctuation(self,old_string):
        new_string = re.sub("-|,|.|?|!|:|;|'|\|/|_"," ",old_string)
        return new_string
    
    def lemmatization(self):
        pass