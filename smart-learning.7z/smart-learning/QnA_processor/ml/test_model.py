import gensim
import pickle
import numpy as np
from QnA_processor.question_analysis.ml.utils import load_data,average_vector,compute_accuracy
from QnA_processor.question_analysis.ml.settings import testing_data_path,word_vector_path,target_classes,model_path

def test_classifier():
    test_data = load_data(testing_data_path)
    word_vector = gensim.models.KeyedVectors.load_word2vec_format(word_vector_path, binary=False)
    classifier = pickle.load(open(model_path, 'rb'))
    if target_classes=="EntityType":
        test_labels = [line[0] for line in test_data]
    else :
        test_labels = [line[0].split(":")[0] for line in test_data]
        
    test_data_prediction = [classifier.predict([np.asarray(average_vector(word_vector, line[1].lower()))]) for line in test_data]
    print ("Testing accuracy " + str(compute_accuracy(test_data_prediction, test_labels)))
    
test_classifier()