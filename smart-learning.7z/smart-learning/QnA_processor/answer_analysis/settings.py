'''
Created on May 9, 2018

@author: 574965
'''

# Custom stopwords path

CUSTOM_STOPWORDS_PATH = r"QnA_processor/data/custom_stopwords.txt"


HTTP_PROXY = 'http://574965:Mar27%402018%23@proxy.cognizant.com:6050'
HTTPS_PROXY = 'https://574965:Mar27%402018%23@proxy.cognizant.com:6050'
QUESTION_CLASSIFIER_URL = "https://language.googleapis.com/v1beta2/documents:classifyText"
GOOGLE_API_KEY = "Bearer ya29.c.Elq3BY-PFCJC4rP1yAg9sCBgMsXYLPm60I4HG_Nbv2-NRQRLm4pHbp70s0nROGHL20T-m8cgAwmVGwvFRkl7-pb67pK0ksWaguoo1_yWv4E7D-D5a_dON3ajqik"